package com.db.awmd.challenge.service;

import com.db.awmd.challenge.domain.Account;
import com.db.awmd.challenge.domain.FundTransfer;
import com.db.awmd.challenge.repository.AccountsRepository;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountsService {

  @Getter
  private final AccountsRepository accountsRepository;
  @Getter
  private final NotificationService notificationService;

  @Autowired
  public AccountsService(AccountsRepository accountsRepository,NotificationService notificationService)
  {
    this.accountsRepository = accountsRepository;
    this.notificationService = notificationService;
  }

  public void createAccount(Account account) {
    this.accountsRepository.createAccount(account);
  }

  public Account getAccount(String accountId) {
    return this.accountsRepository.getAccount(accountId);
  }

  public boolean fundTransfer(FundTransfer fundTransfer) {
    boolean transferStatus =  this.accountsRepository.transferFund(fundTransfer);
    if(transferStatus) {
      this.notificationService.notifyAboutTransfer(this.accountsRepository.getAccount(
              fundTransfer.getSenderAccountId()),
              " Account debitted with " + fundTransfer.getFund());
      this.notificationService.notifyAboutTransfer(this.accountsRepository.getAccount(
              fundTransfer.getReceiverAccountId()),
              " Account Creditted with " + fundTransfer.getFund());
    }
    return transferStatus;
  }
}
